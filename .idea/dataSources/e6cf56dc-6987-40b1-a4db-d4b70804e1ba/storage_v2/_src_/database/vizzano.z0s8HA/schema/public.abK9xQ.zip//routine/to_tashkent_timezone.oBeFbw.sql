create function to_tashkent_timezone(timestamp_value timestamp with time zone) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN
    RETURN timestamp_value AT TIME ZONE 'Asia/Tashkent';
END;
$$;

alter function to_tashkent_timezone(timestamp with time zone) owner to vizzano;

