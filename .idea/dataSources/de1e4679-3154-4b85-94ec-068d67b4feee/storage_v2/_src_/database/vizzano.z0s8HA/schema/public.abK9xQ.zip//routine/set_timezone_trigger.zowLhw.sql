create function set_timezone_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.created_at IS NOT NULL THEN
        NEW.created_at = to_tashkent_timezone(NEW.created_at::timestamp with time zone);
    END IF;
    RETURN NEW;
END;
$$;

alter function set_timezone_trigger() owner to vizzano;

